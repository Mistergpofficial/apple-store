
<link href="{!! asset('public/material/css/bootstrap.min.css') !!}" rel="stylesheet">
<link href="{!! asset('public/material/css/bootstrap-material-design.css') !!}" rel="stylesheet">
<link href="{!! asset('public/material/css/ripples.css') !!}" rel="stylesheet">
<link href="{!! asset('public/material/css/jquery.dropdown.css') !!}" rel="stylesheet">
<link href="{!! asset('public/material/css/style.css') !!}" rel="stylesheet">
<link rel="icon" type="image/png" href="{!! asset('public/favicon.ico') !!}">
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500" type="text/css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>