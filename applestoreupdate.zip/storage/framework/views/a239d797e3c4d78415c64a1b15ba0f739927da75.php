<?php $__env->startSection('content'); ?>
    <section id="content">
        <link rel="stylesheet" href="./css/style.css">

        <div class="bg-primary dk" style="background: url(&#39;images/banner.jpg&#39;);background-size:cover;">

            <div style="background:rgba(0,0,0,0.4)">
                <div class="text-center wrapper">
                    <div class="m-t-xl m-b-xl">
                        <div class="text-uc h1 font-bold inline">
                            <div class="m-r-sm text-center text-white">GIT-EDU  <span class="font-thin text-muted">  </span></div>


                        </div>
                        <div class="h4 text-muted m-t-sm">your best choice SMS...
                        </div>
                    </div>
                    <p class="text-center m-b-xl">
                        <a href="<?php echo e(url('signin')); ?>" class="btn btn-lg btn-warning  bg-empty m-sm">Login</a>

                        or <a href="" class="btn btn-lg btn-warning b-white bg-empty m-sm"> Sign
                            Up
                        </a>
                    </p>
                    <p id="days"></p>
                </div>
                <div class="padder">

                    <div class="hbox">

                        <div class="clearfix"></div>



                    </div>
                </div>

            </div>
        </div>
        </div>


        <div id="about">
            <div class="container">

                <div class="m-t-xl m-b-xl text-center wrapper"><h3>GIT-EDU</h3>
                    <div id="story"></div>
                    <p class="text-muted">
                        GIT-EDU is designed to help school administrators manage their school activites effectively With this application in your school, we guarantee you 100% automation of all your school processes.</p>
                    <br>

                    <!--  <iframe width="560" height="315" src="./images/XMOTw-I2up4.html" frameborder="0" allowfullscreen=""></iframe> -->
                    <div id="about_feature"></div>
                    <br><br>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-md-6">
                        <div class="wow fadeInUp" data-wow-delay="0.2s">
                            <img src="./images/intro-img2.jpg" class="img-responsive" alt="" />
                        </div>
                    </div>
                    <div class="col-sm-3 col-md-3">

                        <div class="wow fadeInRight" data-wow-delay="0.1s">
                            <div class="service-box">
                                <div class="service-icon">
                                    <span class="fa fa-stethoscope fa-3x"></span>
                                </div>
                                <div class="service-desc">
                                    <h5 class="h-light">Result Management</h5>
                                    <p>We help automate your students result and make life easy for your teaching staff.</p>
                                </div>
                            </div>
                        </div>

                        <div class="wow fadeInRight" data-wow-delay="0.2s">
                            <div class="service-box">
                                <div class="service-icon">
                                    <span class="fa fa-wheelchair fa-3x"></span>
                                </div>
                                <div class="service-desc">
                                    <h5 class="h-light">Attendance Management</h5>
                                    <p>Our System is designed to take cognisance of both students and staff attendance record accurately.</p>
                                </div>
                            </div>
                        </div>
                        <div class="wow fadeInRight" data-wow-delay="0.3s">
                            <div class="service-box">
                                <div class="service-icon">
                                    <span class="fa fa-plus-square fa-3x"></span>
                                </div>
                                <div class="service-desc">
                                    <h5 class="h-light">Student Management</h5>
                                    <p>All student information are automated and available when they are needed. Paper record is defeated</p>
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="col-sm-3 col-md-3">

                        <div class="wow fadeInRight" data-wow-delay="0.1s">
                            <div class="service-box">
                                <div class="service-icon">
                                    <span class="fa fa-h-square fa-3x"></span>
                                </div>
                                <div class="service-desc">
                                    <h5 class="h-light">Staff Management</h5>
                                    <p>We also keep proper record of your staffs both teaching and non teaching.We make life easy for you by so doing.</p>
                                </div>
                            </div>
                        </div>

                        <div class="wow fadeInRight" data-wow-delay="0.2s">
                            <div class="service-box">
                                <div class="service-icon">
                                    <span class="fa fa-filter fa-3x"></span>
                                </div>
                                <div class="service-desc">
                                    <h5 class="h-light">Notice Board</h5>
                                    <p>Staff and students do not have to visit notice boards occasionally to get vital information as all notices are made available on our platform and can be accessed on both parties dashboard.</p>
                                </div>
                            </div>
                        </div>


                    </div>







                </div>
            </div>
        </div>





    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>