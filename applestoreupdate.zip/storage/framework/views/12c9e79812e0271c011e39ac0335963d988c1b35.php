<!DOCTYPE html>
<!-- saved from url=(0026)http://mychurchmember.com/ -->
<html lang="en" class="  js no-touch no-android chrome no-firefox no-iemobile no-ie no-ie10 no-ie11 no-ios no-ios7 ipad"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>Welcome | GIT-BLOG</title>
    <meta name="description" content="">
    <meta name="detectify-verification" content="c1b33bd882c3936d9e0f4fca31e74b70">
    <meta name="google-site-verification" content="gOo-RWYqpVogdSR4wAFvmFlrVaYyB8986DEIah1unVs">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="<?php echo asset('css/bootstrap.min.css'); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo asset('css/font-awesome.min.css'); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo asset('css/animate.css'); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo asset('css/owl.carousel.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/slicknav.min.css'); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo asset('css/magnific-popup.css'); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo asset('css/styles.css'); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo asset('css/responsive.css'); ?>" type="text/css">


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


    <link rel="icon" type="image/png" href="<?php echo url('images/ad.jpg'); ?>" width="40px">

<body>

    <!-- header-area start -->
    <header class="header-area header-area3">
        <div class="header-top bg-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-12">
                        <div class="header-top-left">
                            <p>Always post powefull content.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12">
                        <div class="header-top-right text-right">
                            <ul>
                                <li><a href="#">Facebook</a></li>
                                <li><a href="#">Twitter</a></li>
                                <li><a href="#">Behance</a></li>
                                <li><a href="#">Google+</a></li>
                                <li><a href="#">Dribbble</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-middle-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-12 d-none d-lg-block">
                        <div class="mainmenu">
                            <ul id="navigation">
                                <li><a href="javascript:void(0)">Home <i class="fa fa-angle-down"></i></a>
                                    <ul>
                                        <li><a href="index.html">Home One </a></li>
                                        <li><a href="index2.html">Home Two</a></li>
                                        <li><a href="index3.html">Home Three <i class="fa fa-angle-right pull-right"></i></a>
                                            <ul>
                                                <li><a href="javascript:void(0)">Submenu One</a></li>
                                                <li><a href="javascript:void(0)">Submenu Two</a></li>
                                                <li><a href="javascript:void(0)">Submenu Three</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="index4.html">Home Four</a></li>
                                        <li><a href="index5.html">Home Five</a></li>
                                    </ul>
                                </li>
                                <li class="active"><a href="javascript:void(0)">blog <i class="fa fa-angle-down"></i></a>
                                    <ul>
                                        <li class="active"><a href="blog.html">Blog Page</a></li>
                                        <li><a href="blog-left.html">Blog Left</a></li>
                                        <li><a href="blog-right.html">Blog Right</a></li>
                                        <li><a href="javascript:void(0)">Blog Details<i class="fa fa-angle-right pull-right"></i></a>
                                            <ul>
                                                <li><a href="blog-details.html">Blog Images</a></li>
                                                <li><a href="blog-gallary.html">Blog Gallary</a></li>
                                                <li><a href="blog-video.html">Blog Video</a></li>
                                                <li><a href="blog-audio.html">Blog Audio</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="about.html">About</a></li>
                                <li><a href="javascript:void(0)">Pages <i class="fa fa-angle-down"></i></a>
                                    <ul>
                                        <li><a href="about.html">About</a></li>
                                        <li><a href="faq.html">Faq</a></li>
                                        <li><a href="404.html">404 Page</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.html">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 col-12">
                        <div class="logo">
                            <a href="index.html">
                                <img src="<?php echo asset('images/logo.png'); ?>" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-8 col-lg-5 col-sm-9 col-9">
                        <div class="form-style search-form">
                            <form action="#">
                                <input type="text" placeholder="Search here...">
                                <button><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                    <div class="d-block d-lg-none clear col-md-1 col-sm-3 col-3">
                        <div class="responsive-menu-wrap floatright"></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header-area end -->
<?php echo $__env->yieldContent('content'); ?>
<!-- footer-area start -->
    <footer class="footer-area">
        <div class="footer-top-area pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-4 col-12">
                        <div class="footer-widget footer-logo">
                            <img src="assets/images/logo.png" alt="">
                            <p>Duis autem vel eum iriure dolor in hendrerit in esse molestie consemuat vel illum dolore eugt nulla facilisis at vero eros accum.</p>
                            <p>Esse molestie consequat vel illum dolore eugt nulla facilisis at vero eros accum.</p>
                            <ul>
                                <li>
                                    <span>Address:</span> 70 Bowman St.South
                                    <br> Windsor, CT 06074
                                </li>
                                <li>
                                    <span>Contact:</span> +00 568 468 968
                                    <br> +00 469 856 576
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-12">
                        <div class="footer-widget widget_recent_entries">
                            <ul>
                                <li>
                                    <div class="widget_recent_entries-img">
                                        <img src="assets/images/footer/1.jpg" alt="">
                                    </div>
                                    <div class="widget_recent_entries-content">
                                        <h3><a href="blog-details.html">Defying the traditional and mainstream parties courtesy marche.</a></h3>
                                        <h4>Naomi Jefferson</h4>
                                        <span>15 December, 17</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="widget_recent_entries-img">
                                        <img src="assets/images/footer/2.jpg" alt="">
                                    </div>
                                    <div class="widget_recent_entries-content">
                                        <h3><a href="blog-details.html">Packing macron anddis insted about vote against chat bubbleo head.</a></h3>
                                        <h4>Naomi Jefferson</h4>
                                        <span>15 December, 17</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-12">
                        <div class="footer-widget widget_recent_entries">
                            <ul>
                                <li>
                                    <div class="widget_recent_entries-img">
                                        <img src="assets/images/footer/3.jpg" alt="">
                                    </div>
                                    <div class="widget_recent_entries-content">
                                        <h3><a href="blog-details.html">British military courts aginst protester business cultural protocol.</a></h3>
                                        <h4>Naomi Jefferson</h4>
                                        <span>15 December, 17</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="widget_recent_entries-img">
                                        <img src="assets/images/footer/2.jpg" alt="">
                                    </div>
                                    <div class="widget_recent_entries-content">
                                        <h3><a href="blog-details.html">Packing macron anddis insted about vote against chat bubbleo head.</a></h3>
                                        <h4>Naomi Jefferson</h4>
                                        <span>15 December, 17</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="copyright text-center">
                            <p>Copyright 2017, All right reserved <span>Developed by <a href="#">Blogmaster.</a></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer-area end -->


<script src="<?php echo asset('js/jquery-2.2.4.min.js'); ?>"></script>
    <script src="<?php echo asset('js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo asset('js/popper.min.js'); ?>"></script>
    <script src="<?php echo asset('js/owl.carousel.min.js'); ?>"></script>
    <script src="<?php echo asset('js/plugins.js'); ?>"></script>
    <script src="<?php echo asset('js/scripts.js'); ?>"></script>
    <script src="<?php echo asset('js/index.js'); ?>"></script>
</body>
</html>