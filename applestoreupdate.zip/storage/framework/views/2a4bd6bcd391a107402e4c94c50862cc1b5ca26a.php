<?php $__env->startSection('content'); ?>
    <div id="index">
    <!-- breadcumb-area start -->
    <div class="breadcumb-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb-wrap text-center">
                        <h2>Blog Page</h2>
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li>-</li>
                            <li class="active">Blog</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcumb-area end -->
    <!-- blog-area start -->
    <div class="blog-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4  col-md-6 col-12">
                    <div class="blog-wrap">
                        <div class="blog-image">
                            <img src="<?php echo asset('images/1.jpg'); ?>" alt="">
                            <ul>
                                <li>20</li>
                                <li>Janu</li>
                            </ul>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <ul>
                                    <li><a href="#"><i class="fa fa-user"></i> Admin</a></li>
                                    <li><a href="#"><i class="fa fa-heart"></i> Love</a></li>
                                    <li><a href="#"><i class="fa fa-comments"></i> 15 Comments</a></li>
                                </ul>
                            </div>
                            <h3><a href="">British military courts use aginst protesters busines cultural...</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati nulla veniam autem veritatis, adipisci officia? Tempora necessitatibus, iusto minima maxime ipsum quae dolore repellat quaerat.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="blog-wrap">
                        <div class="blog-active">
                            <div class="blog-image">
                                <img src="<?php echo asset('images/5.jpg'); ?>" alt="">
                                <ul>
                                    <li>20</li>
                                    <li>Janu</li>
                                </ul>
                            </div>
                            <div class="blog-image">
                                <img src="<?php echo asset('images/2.jpg'); ?>" alt="">
                                <ul>
                                    <li>15</li>
                                    <li>Jun</li>
                                </ul>
                            </div>
                            <div class="blog-image">
                                <img src="<?php echo asset('images/3.jpg'); ?>" alt="">
                                <ul>
                                    <li>01</li>
                                    <li>April</li>
                                </ul>
                            </div>
                            <div class="blog-image">
                                <img src="<?php echo asset('images/4.jpg'); ?>" alt="">
                                <ul>
                                    <li>14</li>
                                    <li>Maye</li>
                                </ul>
                            </div>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <ul>
                                    <li><a href="#"><i class="fa fa-user"></i> Admin</a></li>
                                    <li><a href="#"><i class="fa fa-heart"></i>1 Love</a></li>
                                    <li><a href="#"><i class="fa fa-comments"></i> 12 Comments</a></li>
                                </ul>
                            </div>
                            <h3><a href="blog-gallary.html">South korea’s moon jae in sworn vowing to address north...</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati nulla veniam autem veritatis, adipisci officia? Tempora necessitatibus, iusto minima maxime ipsum quae dolore repellat quaerat.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="blog-wrap">
                        <div class="blog-image">
                            <img src="<?php echo asset('images/2.jpg'); ?>" alt="">
                            <ul>
                                <li>25</li>
                                <li>Jun</li>
                            </ul>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <ul>
                                    <li><a href="#"><i class="fa fa-user"></i> Admin</a></li>
                                    <li><a href="#"><i class="fa fa-heart"></i> 5 Love</a></li>
                                    <li><a href="#"><i class="fa fa-comments"></i> 18 Comments</a></li>
                                </ul>
                            </div>
                            <h3><a href="blog-details.html">Man looking at his note remember to daily tasks...</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati nulla veniam autem veritatis, adipisci officia? Tempora necessitatibus, iusto minima maxime ipsum quae dolore repellat quaerat.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="blog-wrap">
                        <div class="blog-image">
                            <img src="<?php echo asset('images/3.jpg'); ?>" alt="">
                            <ul>
                                <li>15</li>
                                <li>April</li>
                            </ul>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <ul>
                                    <li><a href="#"><i class="fa fa-user"></i> Admin</a></li>
                                    <li><a href="#"><i class="fa fa-heart"></i>15 Love</a></li>
                                    <li><a href="#"><i class="fa fa-comments"></i> 08 Comments</a></li>
                                </ul>
                            </div>
                            <h3><a href="blog-video.html">Robots helped inspire and deep learning might become...</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati nulla veniam autem veritatis, adipisci officia? Tempora necessitatibus, iusto minima maxime ipsum quae dolore repellat quaerat.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="blog-wrap">
                        <div class="blog-image">
                            <img src="<?php echo asset('images/4.jpg'); ?>" alt="">
                            <ul>
                                <li>25</li>
                                <li>May</li>
                            </ul>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <ul>
                                    <li><a href="#"><i class="fa fa-user"></i> Admin</a></li>
                                    <li><a href="#"><i class="fa fa-heart"></i> 5 Love</a></li>
                                    <li><a href="#"><i class="fa fa-comments"></i> 30 Comments</a></li>
                                </ul>
                            </div>
                            <h3><a href="blog-details.html">Defying the traditional and mainstream parties...</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati nulla veniam autem veritatis, adipisci officia? Tempora necessitatibus, iusto minima maxime ipsum quae dolore repellat quaerat.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <div class="blog-wrap">
                        <div class="blog-image">
                            <img src="<?php echo asset('images/2.jpg'); ?>" alt="">  <ul>
                                <li>01</li>
                                <li>Feb</li>
                            </ul>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <ul>
                                    <li><a href="#"><i class="fa fa-user"></i> Admin</a></li>
                                    <li><a href="#"><i class="fa fa-heart"></i> 16 Love</a></li>
                                    <li><a href="#"><i class="fa fa-comments"></i>8 Comments</a></li>
                                </ul>
                            </div>
                            <h3><a href="blog-audio.html">Packing macron anddis insted about vote against chat...</a></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati nulla veniam autem veritatis, adipisci officia? Tempora necessitatibus, iusto minima maxime ipsum quae dolore repellat quaerat.</p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="pagination-wrapper text-center mb-30">
                        <ul class="page-numbers">
                            <li><a class="prev page-numbers" href="#"><i class="fa fa-arrow-left"></i></a></li>
                            <li><span class="page-numbers current">1</span></li>
                            <li><a class="page-numbers" href="#">2</a></li>
                            <li><a class="page-numbers" href="#">3</a></li>
                            <li><a class="next page-numbers" href="#"><i class="fa fa-arrow-right"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- blog-area end -->
    <!-- instagram-area start -->
    <div class="instagram-area mb-80">
        <div class="instagram-wrap">
            <a href="#"><img src="<?php echo asset('images/1.jpg'); ?>" alt=""></a>
        </div>
        <div class="instagram-wrap">
            <a href="#"><img src="<?php echo asset('images/2.jpg'); ?>" alt=""></a>
        </div>
        <div class="instagram-wrap">
            <a href="#"><img src="<?php echo asset('images/3.jpg'); ?>" alt=""></a>
        </div>
        <div class="instagram-wrap">
            <a href="#"><img src="<?php echo asset('images/4.jpg'); ?>" alt=""></a>
        </div>
        <div class="instagram-wrap">
            <a href="#"><img src="<?php echo asset('images/5.jpg'); ?>" alt=""></a>
        </div>
        <div class="instagram-wrap">
            <a href="#"><img src="<?php echo asset('images/2.jpg'); ?>" alt=""></a>
        </div>
        <div class="instagram-content">
            <a href="#">Follow Instragram</a>
        </div>
    </div>
    <!-- instagram-area end -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>