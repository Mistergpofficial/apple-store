<!DOCTYPE html>
<html lang="en" xmlns:v-bind="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="EasyLoan - is the Loan Company Website Template.">
    <meta name="keywords" content="Loan Company, Loan Agency, Students Loan, Car Loan, Home Loan, Loan Product, Personal Loan, Bad credit, Loan Advisor, Financial Website Template, Banking, Loan provider, Bootstrap Template, Landing Page, EasyLoan">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Welcome - Teesan</title>


    <link rel="icon" type="image/png" href="<?php echo asset('images/logo.png'); ?>" width="40px">


    <link rel="stylesheet" href="<?php echo asset('css/font-awesome.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/select2.css'); ?>">

    <link rel="stylesheet" href="<?php echo asset('css/quirk.css'); ?>">

    <script src="<?php echo asset('js/modernizr.js'); ?>"></script>
    <!-- pass php vars to javascript -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'appUrl' => url("/"),
            'siteUser' => auth()->user(),
        ]); ?>
    </script>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="../lib/html5shiv/html5shiv.js"></script>
    <script src="../lib/respond/respond.src.js"></script>
    <![endif]-->
</head>

<body class="signwrapper"  style="background-color: orange;">
<div id="index">
    <Register></Register>
</div>
<script src="<?php echo asset('js/jquery.min.js'); ?>"></script>
<script src="<?php echo asset('js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo asset('js/select2.js'); ?>"></script>
<script src="<?php echo asset('js/index.js'); ?>"></script>
<script>
    $(function() {

        // Select2 Box
        $("select.form-control").select2({ minimumResultsForSearch: Infinity });

    });
</script>



</body></html>
