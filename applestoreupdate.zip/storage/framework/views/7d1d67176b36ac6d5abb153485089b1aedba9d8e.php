<?php $__env->startSection('title', ' | SignUp '); ?>
<?php $__env->startSection('content'); ?>
    <section id="content" class="m-t-lg wrapper-md animated fadeInUp">
        <div class="container aside-xl"> <a class="navbar-brand block" href="<?php echo e(url('/')); ?>">Admin Signup</a>
            <section class="m-b-lg">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <header class="wrapper text-center"> <strong>Sign up</strong> </header>
                <form action="<?php echo e(route('auth.a_register')); ?>" method="post" >
                <?php echo e(csrf_field()); ?>

                    <div class="list-group">
                        <div class="list-group-item">
                            <span class="req"></span>
                            <input type="text" placeholder="Full Name" class="form-control no-border" name="full_name" value="<?php echo e(old('full_name')); ?>" >
                           <?php if($errors->has('full_name')): ?>
                            <span class="help-block">
                             <strong class="bg-white" style="color: red;"><?php echo e($errors->first('full_name')); ?></strong>
                            </span>
                               <?php endif; ?>
                        </div>
                        <div class="list-group-item">
                            <span class="req"></span>
                            <input type="email" placeholder="email" class="form-control no-border" name="email" value="<?php echo e(old('email')); ?>">
                            <?php if($errors->has('email')): ?>
                            <span class="help-block">
                             <strong class="bg-white" style="color: red;"><?php echo e($errors->first('email')); ?></strong>
                            </span>
                                <?php endif; ?>
                        </div>
                        <div class="list-group-item">
                            <span class="req"></span>
                            <input type="text" placeholder="Phone Number" class="form-control no-border" name="phonenum" value="<?php echo e(old('phonenum')); ?>">
                            <?php if($errors->has('phonenum')): ?>
                            <span class="help-block">
                             <strong class="bg-white" style="color: red;"><?php echo e($errors->first('phonenum')); ?></strong>
                            </span>
                                <?php endif; ?>
                        </div>
                        <div class="list-group-item">
                            <span class="req"></span>
                            <input type="password" placeholder="Password" class="form-control no-border" name="password">
                            <span class="help-block">
                             <strong class="bg-white" style="color: red;"><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        </div>

                        <div class="list-group-item">
                            <span class="req"></span>
                            <input type="password" placeholder="Password Confirmation"  class="form-control no-border" name="password_confirmation"  autocomplete="off" >
                            <span class="help-block">
                             <strong class="bg-blue" style="color: red;"><?php echo e($errors->first('password_confirm')); ?></strong>
                            </span>
                        </div>
                    </div>
                    <input type="submit" value="Submit" class="btn btn-lg btn-primary btn-block">
                    <div class="text-center m-t m-b"><a href=""><small>Forgot password?</small></a></div>
                    <div class="line line-dashed"></div>

                    <a href="<?php echo e(route('auth.signin')); ?>" class="btn btn-lg btn-primary btn-block">Already have an account?</a>

                </form>
            </section>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>