<html lang="zxx"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style type="text/css">.pac-container{background-color:#fff;position:absolute!important;z-index:1000;border-radius:2px;border-top:1px solid #d9d9d9;font-family:Arial,sans-serif;box-shadow:0 2px 6px rgba(0,0,0,0.3);-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box;overflow:hidden}.pac-logo:after{content:"";padding:1px 1px 1px 0;height:16px;text-align:right;display:block;background-image:url(https://maps.gstatic.com/mapfiles/api-3/images/powered-by-google-on-white3.png);background-position:right;background-repeat:no-repeat;background-size:120px 14px}.hdpi.pac-logo:after{background-image:url(https://maps.gstatic.com/mapfiles/api-3/images/powered-by-google-on-white3_hdpi.png)}.pac-item{cursor:default;padding:0 4px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;line-height:30px;text-align:left;border-top:1px solid #e6e6e6;font-size:11px;color:#999}.pac-item:hover{background-color:#fafafa}.pac-item-selected,.pac-item-selected:hover{background-color:#ebf2fe}.pac-matched{font-weight:700}.pac-item-query{font-size:13px;padding-right:3px;color:#000}.pac-icon{width:15px;height:20px;margin-right:7px;margin-top:6px;display:inline-block;vertical-align:top;background-image:url(https://maps.gstatic.com/mapfiles/api-3/images/autocomplete-icons.png);background-size:34px}.hdpi .pac-icon{background-image:url(https://maps.gstatic.com/mapfiles/api-3/images/autocomplete-icons_hdpi.png)}.pac-icon-search{background-position:-1px -1px}.pac-item-selected .pac-icon-search{background-position:-18px -1px}.pac-icon-marker{background-position:-1px -161px}.pac-item-selected .pac-icon-marker{background-position:-18px -161px}.pac-placeholder{color:gray}
    </style>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="EasyLoan - is the Loan Company Website Template.">
    <meta name="keywords" content="Loan Company, Loan Agency, Students Loan, Car Loan, Home Loan, Loan Product, Personal Loan, Bad credit, Loan Advisor, Financial Website Template, Banking, Loan provider, Bootstrap Template, Landing Page, EasyLoan">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Welcome - Teesan</title>
    <link rel="shortcut icon" href="http://onushorit.com/EasyLoan/img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="http://onushorit.com/EasyLoan/img/favicon.ico" type="image/x-icon">

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo asset('css/bootstrap.min.css'); ?>" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo asset('css/cssdp'); ?>" rel="stylesheet">
    <!-- Plugin CSS -->
    <link href="<?php echo asset('css/font-awesome.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('css/simple-line-icons.css'); ?>" rel="stylesheet">
    <!-- Preloader CSS -->
    <link href="<?php echo asset('css/preloader.css'); ?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo asset('css/custom.css'); ?>" rel="stylesheet">
    <!-- Responsive CSS -->
    <link href="<?php echo asset('css/responsive.css'); ?>" rel="stylesheet">

    <!-- pass php vars to javascript -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'appUrl' => url("/")
        ]); ?>
    </script>



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" charset="UTF-8" src="<?php echo asset('js/common.js'); ?>"></script>
    <script type="text/javascript" charset="UTF-8" src="<?php echo asset('js/util.js'); ?>"></script>
    <script type="text/javascript" charset="UTF-8" src="<?php echo asset('js/controls.js'); ?>"></script>
    <script type="text/javascript" charset="UTF-8" src="<?php echo asset('js/places_impl.js'); ?>"></script>
    <script type="text/javascript" charset="UTF-8" src="<?php echo asset('js/stats.js'); ?>"></script>
</head>

<body id="page-top" style="overflow: visible;">

<!-- Preloader -->
<div id="preloader" style="display: none;">
    <div id="wave" style="display: none;"></div>
</div>
<div id="mask"></div><!-- End Of Preloader -->

<!-- NavBar -->
<nav id="mainNav" class="navbar navbar-default navbar-fixed-top affix">
    <div class="container">
        <!-- Brand Logo -->
        <div class="navbar-header">
            <a class="navbar-brand page-scroll" href="http://onushorit.com/EasyLoan/without_amount_slider.html#page-top">
                <img src="<?php echo asset('images/logo.png'); ?>" alt="LOGO">
            </a>
        </div>

        <!-- Social Link -->
        <div class="social_link">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a class="" href="http://onushorit.com/EasyLoan/without_amount_slider.html#"><i class="icon-social-facebook"></i></a>
                </li>
                <li>
                    <a class="" href="http://onushorit.com/EasyLoan/without_amount_slider.html#"><i class="icon-social-twitter"></i></a>
                </li>
                <li>
                    <a class="" href="http://onushorit.com/EasyLoan/without_amount_slider.html#"><i class="icon-social-skype"></i></a>
                </li>
            </ul>
        </div>
    </div>
</nav><!-- End Of Nav Bar -->


<!-- Header -->
<header id="page_top" class="car_loan">
    <div class="container">
        <div class="row">
            <div class="col-sm-7">
                <div class="header-content">
                    <div class="header-content-inner">
                        <h1>Find Artisans Close to you</h1>
                        <p>Alot of Nigerians would like to employ the services of an artisan right from their comfort zone..Hence the need for Teesan</p>
                        
                        <a href="<?php echo route('auth.register'); ?>" class="btn btn-outline btn-xl page-scroll">For Artisans</a> &nbsp; &nbsp;  <a href="http://onushorit.com/EasyLoan/without_amount_slider.html#features" >Sign In</a>&nbsp; &nbsp;  <a href="http://onushorit.com/EasyLoan/without_amount_slider.html#features">Sign Up</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="form-container">
                    <div class="form-mockup">
                        <h2>Request An Artisan Now</h2>
                        <h4>Easy to apply for the services of an artisan with us,Once you have complete this form. </h4>
                        <form action="" method="post">
                            <div class="form-group">
                                <input type="text" name="name" class="form-control" placeholder="Name" required="">
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control" placeholder="E-mail" required="">
                            </div>
                            <div class="form-group">
                                <input type="text" name="phone" class="form-control" placeholder="Phone" required="">
                            </div>
                            <div class="form-group">
                                <input type="text" id="autocomplete" name="city" class="form-control" placeholder="Type Your City Name" required="" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="zip_code" placeholder="Zip Code" required="">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="amount" placeholder="Type Your Amount" required="">
                            </div>
                            <button type="submit" class="btn btn-default quote_btn">Send Request</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><!-- End Of Header -->
<?php echo $__env->yieldContent('content'); ?>
<!-- Footer -->
<footer>
    <div class="container">
        <p>© 2017 EasyLoan. All Rights Reserved.</p>
        <ul class="list-inline">
            <li>
                <a href="http://onushorit.com/EasyLoan/without_amount_slider.html#">Privacy</a>
            </li>
            <li>
                <a href="http://onushorit.com/EasyLoan/without_amount_slider.html#">Terms</a>
            </li>
        </ul>
    </div>
</footer>
<!-- End Of Footer -->


<script src="<?php echo asset('js/jquery.min.js'); ?>"></script>
    <script src="<?php echo asset('js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo asset('js/jquery.easing.js'); ?>"></script>
    <script src="<?php echo asset('js/jquery.counterup.js'); ?>"></script>
    <script src="<?php echo asset('js/jquery.waypoints.js'); ?>"></script>
    <script src="<?php echo asset('js/price.slider.js'); ?>"></script>
<script src="<?php echo asset('js/custom.js'); ?>"></script>
<script src="<?php echo asset('js/testimonials.js'); ?>"></script>
<script src="<?php echo asset('js/jsdp'); ?>"></script>
<script src="<?php echo asset('js/index.js'); ?>"></script>
</body>
</html>