<?php $__env->startSection('content'); ?>

    <section id="content" class="m-t-lg wrapper-md animated fadeInUp">
        <div class="container aside-xl"> <a class="navbar-brand block" href="<?php echo e(url('/')); ?>">GIT-SCHOOL</a>
            <section class="m-b-lg">

                <?php if(Session::has('danger')): ?>
                    <div class="alert alert-success">
                        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
                        <?php echo e(Session::get('danger')); ?>

                    </div>
                <?php endif; ?>

                <header class="wrapper text-center"> <strong>Sign in to view details</strong> </header>
                <form action="<?php echo e(route('auth.signin')); ?>" method="post" >
                    <?php echo e(csrf_field()); ?>

                    <div class="list-group">
                        <div class="list-group-item">
                            <input type="email" placeholder="Email" class="form-control no-border" name="email" value="" >
                            <span class="help-block">
                             <strong class="bg-white" style="color: red;"><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        </div>
                        <div class="list-group-item">
                            <input type="password" placeholder="Password" class="form-control no-border" name="password" value="" >
                            <span class="help-block">
                             <strong class="bg-white" style="color: red;"><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-lg btn-primary btn-block">Submit</button>
                    <div class="text-center m-t m-b"><a href="<?php echo e(route('password.request')); ?>"><small>Forgot password?</small></a></div>
                    <div class="line line-dashed"></div>
                    <a href="" class="btn btn-lg btn-primary btn-block">Don't have an account yet?</a>

                </form>
            </section>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>