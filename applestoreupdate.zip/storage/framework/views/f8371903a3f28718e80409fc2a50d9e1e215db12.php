<!DOCTYPE html>
<html xmlns:v-on="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Git-School | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <script>window.Laravel = { csrfToken: '<?php echo e(csrf_token()); ?>' };</script>
    <meta name="_token" content="<?php echo e(csrf_token()); ?>"/>
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="./css/admin/bootstrap.min.css">
    <link rel="stylesheet" href="./css/app.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous"> <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <!-- jvectormap -->
    <link rel="stylesheet" href="./css/admin/jquery-jvectormap-1.2.2.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="./css/admin/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="./css/admin/all-skins.min.css">

    <link rel="stylesheet" href="./css/admin/styles.css">

    <link rel="icon" type="image/png" href="./images/ad.jpg" width="40px">
    <style type="text/css">
        #header{
            width: 100%;
            height: 10rem;
            overflow: auto;
        }
        #headspace{
            width: 100%;
            height: 42%;
        }
    </style>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">


<?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Dashboard
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Manage / Section</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <section>
                <section class="hbox stretch">


                    <section id="content">
                        <section class="vbox">
                            <header class="header bg-white b-b b-light">
                            </header>
                            <section class="scrollable wrapper">
                                <div class="row">

                                    <span class="col-sm-12 portlet">
                                        <section class="panel panel-success portlet-item">
                                            <header class="panel-heading">Manage Subject </header>
                                            <section class="panel panel-default">
<br>



                                                <!--         <button class="btn btn-primary" type="submit" data-toggle="modal" data-target="#upload_image_modal">
                                                             <span class="glyphicon glyphicon-plus"></span> ADD CLASS
                                                         </button> -->


                                                             <div class="panel-body">
                                                                 <div id="app">
                                                                     <add-subject></add-subject>
                                                                     <subject-one></subject-one>

                                                                 </div>
                                                            </div>
                                                <!-- panel body ends -->


                                </div>
                            </section>
                        </section>

    </div>
</div>
</section>
</section>
<a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
</section>
</section>
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<div id="app">
    <add-class></add-class>

</div>
<footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>Copyright &copy; 2017 <a href="">Gitschool.</a></strong> All rights
    reserved.
</footer>
<?php echo $__env->make('partials.class_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <form action="<?php echo e(url('upload-profile-picture')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input name="id" class="hidden" value="<?php echo e(Auth::user()->id); ?>">
        <div class="image-upload">
            <label for="file-input">
                <img src="<?php echo asset('images/index5.png'); ?>">
            </label>
            <input id="file-input" type="file" name="pro_image">
            <button type="submit" class="btn btn-success">Upload</button>
        </div>
    </form>
</aside>
<!-- /.control-sidebar -->
<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="./js/admin/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="./js/admin/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="./js/admin/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="./js/admin/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="./js/admin/demo.js"></script>
<script src="<?php echo e(asset('js/admin/update_class.js')); ?>"></script>

<script language="text/javascript">
    populateCountries("country", "state"); // first parameter is id of country drop-down and second parameter is id of state drop-down
    populateCountries("country2");
    populateCountries("country2");
</script>

<script type="text/javascript" src="./js/admin/crs.min.js"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
