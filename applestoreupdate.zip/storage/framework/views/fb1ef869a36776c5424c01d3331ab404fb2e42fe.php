
<!-- Edit Teacher Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!--Modal Content -->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" role="form">
                    <?php echo e(csrf_field()); ?>



                    <p class="error text-center alert alert-danger hidden"></p>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="id">ID:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="fid" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="full_name">FULL NAME:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="full_name"  id="full_name" >

                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="email">EMAIL:</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" id="email" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="phonenum">PHONE NUMBER:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="phonenum" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="dob">DATE OF BIRTH:</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" id="dob" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="age">AGE:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="age" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="address">ADDRESS:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="address" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="country">COUNTRY:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="country" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="region">REGION:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="region" >
                        </div>
                    </div>
                </form>
                <div class="deleteContent">
                    Are you sure you want to delete <span class="fname"></span> ? <span class="hidden did"></span>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn actionBtn" data-dismiss="modal">
                        <span id="footer_action_button" class="glyphicon"></span>
                    </button>
                    <button type="button" class="btn btn-warning" data-dismiss="modal">
                        <span class="fa fa-close"></span>Close
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
