<?php
/**
 * Created by PhpStorm.
 * User: GODSPOWER
 * Date: 4/11/2019
 * Time: 1:23 AM
 */
?>


<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <?php if(count($individualapps) === 0): ?>
        <title><?php echo e($item_title); ?> - <?php echo e(config('siteconfig.app_page_title')); ?> - <?php echo e(config('siteconfig.site_title')); ?></title>
    <?php else: ?>
        <?php $__currentLoopData = $individualapps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individualapp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <title><?php echo e($individualapp->track_name); ?> - <?php echo e(config('siteconfig.app_page_title')); ?> - <?php echo e(config('siteconfig.site_title')); ?></title>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(count($individualapps) === 0): ?>
        <meta name="description" content="<?php echo e($item_title); ?>- <?php echo config('siteconfig.app_page_title') ?> - <?php echo config('siteconfig.site_title') ?>" />
        <meta name="keywords" content="<?php echo e($item_title); ?>, <?php echo config('siteconfig.site_keywords') ?>" />
        <meta property="og:site_name" content="<?php echo config('siteconfig.site_title') ?>"/>
        <meta property="og:type" content="article"/>
        <meta property="og:title" content="<?php echo e($item_title); ?> - <?php echo config('siteconfig.app_page_title') ?> - <?php echo config('siteconfig.site_title') ?>"/>
        <meta property="og:description" content="<?php echo e($item_title); ?> - <?php echo config('siteconfig.app_page_title') ?> - <?php echo config('siteconfig.site_title') ?>"/>
        <meta property="og:image" content="<?php echo e($main_image); ?>">
    <?php else: ?>
        <?php $__currentLoopData = $individualapps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individualapp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <meta name="description" content="<?php echo e($individualapp->track_name); ?> - <?php echo config('siteconfig.app_page_title') ?> - <?php echo config('siteconfig.site_title') ?>" />
            <meta name="keywords" content="<?php echo e($individualapp->track_name); ?>, <?php echo config('siteconfig.site_keywords') ?>" />
            <meta property="og:site_name" content="<?php echo config('siteconfig.site_title') ?>"/>
            <meta property="og:type" content="article"/>
            <meta property="og:title" content="<?php echo e($individualapp->track_name); ?> - <?php echo config('siteconfig.app_page_title') ?> - <?php echo config('siteconfig.site_title') ?>"/>
            <meta property="og:description" content="<?php echo e($individualapp->track_name); ?> - <?php echo config('siteconfig.app_page_title') ?> - <?php echo config('siteconfig.site_title') ?>"/>
            <meta property="og:image" content="<?php echo e($individualapp->image); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
     <!-- CSS and Scripts -->
    <?php echo $__env->make('includes.headscripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('ads.head_code', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('url_slug', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php
    // Snippet from PHP Share: http://www.phpshare.org
    function formatSizeUnits($bytes)
    {
    if ($bytes >= 1073741824)
    {
    $bytes = number_format($bytes / 1073741824, 2) . ' GB';
    }
    elseif ($bytes >= 1048576)
    {
    $bytes = number_format($bytes / 1048576, 2) . ' MB';
    }
    elseif ($bytes >= 1024)
    {
    $bytes = number_format($bytes / 1024, 2) . ' kB';
    }
    elseif ($bytes > 1)
    {
    $bytes = $bytes . ' bytes';
    }
    elseif ($bytes == 1)
    {
    $bytes = $bytes . ' byte';
    }
    else
    {
    $bytes = '0 bytes';
    }

    return $bytes;
    }

    ?>

<?php if($individualapps->count() > 0): ?>
    <?php $__currentLoopData = $individualapps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individualapp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="headpage">
            <div class="container">
                <div class="headpageimage">
                    <img data-src="<?php echo asset($individualapp->image); ?>" src="<?php echo config('siteconfig.site_url')?>/public/images/loading.svg" alt="<?php echo e($individualapp->track_name); ?>" height="200px" width="200px">
                </div>
                <div class="headpageinfo">
                    <h1 class="product-title"><?php echo e($individualapp->track_name); ?></h1>
                    <h2 class="product-stock"><?php echo config('siteconfig.byartist_mpage')?> <?php echo e($individualapp->artist_name); ?></h2>
                    <ul style="list-style:none;padding: 0px;">
                        <li><b><?php echo config('siteconfig.cat_mpage')?>:</b> <a href="<?php echo e(url('/category/' . $individualapp->genre_ids[0] . '/' . cano($individualapp->genre_title))); ?>"><?php echo e($individualapp->genre_title); ?></a></li>
                        <li><b><?php echo config('siteconfig.release_mpage') ?>:</b> <?php echo e($individualapp->release_date); ?></li>
                        <li><b><?php echo config('siteconfig.curv_mpage') ?>:</b> <?php echo e($individualapp->version); ?></li>
                        <li><b><?php echo config('siteconfig.adrat_mpage') ?>:</b> <?php echo e($individualapp->content_advisory); ?></li>
                        <li><b><?php echo config('siteconfig.filsz_mpage') ?>:</b> <?php echo e(formatSizeUnits($individualapp->file_size_bytes)); ?></li>
                        <?php if(isset($individualapp->seller_url) && $individualapp->seller_url == true): ?>
                            <li><b><?php echo config('siteconfig.dev_mpage')?>: <a href="<?php echo asset($individualapp->seller_url); ?>" target="_blank" rel="nofollow"><?php echo e($individualapp->artist_name); ?></a></b></li>
                        <?php else: ?>
                            <b><?php echo config('siteconfig.dev_mpage')?>: <?php echo e($individualapp->artist_name); ?></b>
                        <?php endif; ?>
                        <li><b><?php echo config('siteconfig.comp_mpage')?>:</b> <?php echo config('siteconfig.req_mpage')?> <?php echo e($individualapp->minimum_os_version); ?> <?php echo config('siteconfig.req_end_mpage')?></li>
                    </ul>
                </div>
                <div class="headpageright">
                    <?php if(isset($individualapp->average_user_rating) && !empty($individualapp->average_user_rating)): ?>
                        <div class="product-rating">
                            <div class="score"><span><?php echo config('siteconfig.score_mpage')?>: <?php echo e($individualapp->average_user_rating); ?></span></div>
                            <div class="bigstarbox">
                                <span class="bigstars"><?php echo e($individualapp->average_user_rating); ?></span>
                            </div>
                            <div class="scorecount"><span><?php echo config('siteconfig.from_mpage')?> <?php echo e(number_format($individualapp->user_rating_counting)); ?><?php echo config('siteconfig.ratings_mpage')?></span></div>
                        </div>
                    <?php endif; ?>
                        <div class="postactions">
                            <?php if(isset($musicid) && !empty($musicid)): ?>
                                <a href="<?php echo e($individualapp->geo_link); ?>&at=<?php echo e($musicid); ?>" target="_blank" class="btn btn-raised btn-warning"><?php echo e($individualapp->formatted_price); ?> <?php echo config('siteconfig.itunelink_mpage') ?></a>
                            <?php endif; ?>
                            <div style="display: inline-block;float: right;">
                                <div class="addthis_toolbox addthis_default_style addthis_32x32_style">
                                    <a class="addthis_button_preferred_1"></a>
                                    <a class="addthis_button_preferred_2"></a>
                                    <a class="addthis_button_preferred_3"></a>
                                    <a class="addthis_button_compact"></a>
                                </div>
                            </div>
                        </div>


            </div>
        </div>


            <div class="container">
                <div class="col-md-8" style="margin-top: 30px;padding-left:0px;">
                    <div class="postmain">
                        <div class="postmaintitle" style="margin-bottom:5px;">
                            <h3><?php echo config('siteconfig.descriphead_mpage') ?></h3>
                        </div>
                        <div class="postmaindescr">
                            <p>
                                <?php echo e($individualapp->description); ?>

                            </p>
                        </div>
                    </div>
                    <!-- end .postmain -->


                    <div class="postmain">
                        <div class="postmaintitle">
                            <h3><?php echo config('siteconfig.scrhead_mpage')?></h3>
                        </div>
                        <div class="postscreens">

                            <?php $__currentLoopData = $individualapp->screenshots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screenshotUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="fancybox" rel="group" href="<?php echo e($screenshotUrl); ?>"><img src="<?php echo asset($screenshotUrl); ?>"></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                    <!-- end .postmain -->
                    <?php
                        $reviewshead_mpage = config('siteconfig.reviewshead_mpage');
                        $reviewsby_mpage = config('siteconfig.reviewsby_mpage');
                    ?>

                    <?php if(!empty($customerReviews)): ?>
                    <div class="postmain">
                        <div class="postmaintitle">
                            <h3><?php echo config('siteconfig.reviewshead_mpage') ?></h3>
                        </div>
                        <div id="reviews">
                            <ul style="list-style:none;padding: 0px;">
                               <?php $__currentLoopData = $customerReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($counter++ == 0): ?>
                                        <?php continue; ?>;
                                    <?php endif; ?>
                                    <?php if($counter < $max): ?>
                                    <li>
                                        <h4 class=\"tit\"><?php echo e($cus->label); ?></h4>
                                        <div class="starbox"><span class="stars"><?php echo e($cus->rating); ?></span></div>
                                        <div class=\"auth\"><?php echo config('siteconfig.reviewsby_mpage') ?> <?php echo e($cus->author); ?></div>
                                        <div class=\"cont\"><?php echo e($cus->content); ?></div>
                                    </li>
                                        <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                        <?php else: ?>
                        <?php
                            {}
                        ?>
                        <?php endif; ?>


                    <?php
                        $disqus_shortname = config('siteconfig.disqus_shortname');
                    ?>
                     <?php if(isset($disqus_shortname) and !empty($disqus_shortname)): ?>
                    <div class="postmain">
                        <div class="postmaintitle">
                            <h3><?php echo config('siteconfig.commentbox_mpage')?></h3>
                        </div>
                        <div class="videocomments">
                            <div id="disqus_thread"></div>
                            <script type="text/javascript">
                                /* * * CONFIGURATION VARIABLES * * */
                                var disqus_shortname = '<?php echo config('siteconfig.$disqus_shortname')?>';

                                /* * * DON'T EDIT BELOW THIS LINE * * */
                                (function() {
                                    var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
                                    dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
                                    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
                                })();
                            </script>
                            <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>
                        </div>
                    </div>
                    <?php endif; ?>
                <!-- end .postmain -->
                </div>
                <!-- .post-sidebar -->
                <div class="col-md-4" style="padding-right:0px;">
                    <div class="post-sidebar">
                        <div class="post-sidebar-box">
                            <h3><?php echo config('siteconfig.morebyartist_mpage');?> <?php echo e($individualapp->artist_name); ?></h3>
                            <?php $__currentLoopData = $extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="side-itemlist">
                                <li class="side-item">
                                    <div class="side-thumb">
                                        <a href="<?php echo e(url('/app/' . $extra->track_id . '/' . cano($extra->track_name))); ?>">
                                            <img data-src="<?php echo asset($extra->art_work_url); ?>" src="<?php echo asset('public/images/loading.svg'); ?>" >
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h3>
                                            <a href="<?php echo e(url('/app/' . $extra->track_id . '/' . cano($extra->track_name))); ?>"><?php echo e($extra->track_name); ?></a>
                                        </h3>
                                        <h4><?php echo e($extra->artist_name); ?></h4>

                                       <div class="starbox">
                                           <span class="stars"><?php echo e($extra->average_user_rating); ?></span>
                                       </div>

                                        </div></li>

                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>

                <!-- end .post-sidebar -->
            </div>






                </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>

    <div class="headpage">
        <div class="container">
            <div class="headpageimage">
                <img data-src="<?php echo asset($main_image); ?>" src="<?php echo config('siteconfig.site_url')?>/public/images/loading.svg" alt="<?php echo e($item_title); ?>" height="200px" width="200px">
            </div>
            <div class="headpageinfo">
                <h1 class="product-title"><?php echo e($item_title); ?></h1>
                <h2 class="product-stock"><?php echo config('siteconfig.byartist_mpage')?> <?php echo e($artist_title); ?></h2>
                <ul style="list-style:none;padding: 0px;">
                    <li><b><?php echo config('siteconfig.cat_mpage')?>:</b> <a href="<?php echo e(url('/category/' . $genreIds[0] . '/' .cano($genre_title))); ?>"><?php echo e($genre_title); ?></a></li>
                    <li><b><?php echo config('siteconfig.release_mpage') ?>:</b> <?php echo e($releaseDate); ?></li>
                    <li><b><?php echo config('siteconfig.curv_mpage') ?>:</b> <?php echo e($version); ?></li>
                    <li><b><?php echo config('siteconfig.adrat_mpage') ?>:</b> <?php echo e($contentAdvisoryRating); ?></li>
                    <li><b><?php echo config('siteconfig.filsz_mpage') ?>:</b> <?php echo e(formatSizeUnits($fileSizeBytes)); ?></li>
                    <?php if(isset($response->results[0]->sellerUrl) && $response->results[0]->sellerUrl == true): ?>
                        <li><b><?php echo config('siteconfig.dev_mpage')?>:</b> <a href="<?php echo asset($response->results[0]->sellerUrl); ?>" target="_blank" rel="nofollow"><?php echo e($artist_title); ?></a></li>
                    <?php else: ?>
                        <b><?php echo config('siteconfig.dev_mpage')?>: <?php echo e($artist_title); ?></b>
                    <?php endif; ?>
                    <li><b><?php echo config('siteconfig.comp_mpage')?>:</b> <?php echo config('siteconfig.req_mpage')?> <?php echo e($minimumOsVersion); ?> <?php echo config('siteconfig.req_end_mpage')?></li>
                </ul>
            </div>
            <div class="headpageright">
                <?php if(isset($response->results[0]->averageUserRating) and !empty($response->results[0]->averageUserRating)): ?>
                    <div class="product-rating">
                        <div class="score"><span><?php echo config('siteconfig.score_mpage')?>: <?php echo $response->results[0]->averageUserRating;?></span></div>
                        <div class="bigstarbox">
                            <span class="bigstars"><?php echo $response->results[0]->averageUserRating;?></span>
                        </div>
                        <div class="scorecount"><span><?php echo config('siteconfig.from_mpage')?> <?php echo number_format($response->results[0]->userRatingCount);?> <?php echo config('siteconfig.ratings_mpage')?></span></div>
                    </div>
                <?php endif; ?>



                <div class="postactions">
                    <?php if(isset($musicid) && !empty($musicid)): ?>
                        <a href="<?php echo e($geo_link); ?>&at=<?php echo e($musicid); ?>" target="_blank" class="btn btn-raised btn-warning"><?php echo $response->results[0]->formattedPrice;?> <?php echo config('siteconfig.itunelink_mpage') ?></a>
                    <?php endif; ?>
                    <div style="display: inline-block;float: right;">
                        <div class="addthis_toolbox addthis_default_style addthis_32x32_style">
                            <a class="addthis_button_preferred_1"></a>
                            <a class="addthis_button_preferred_2"></a>
                            <a class="addthis_button_preferred_3"></a>
                            <a class="addthis_button_compact"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="col-md-8" style="margin-top: 30px;padding-left:0px;">
            <div class="postmain">
                <div class="postmaintitle" style="margin-bottom:5px;">
                    <h3><?php echo config('siteconfig.descriphead_mpage') ?></h3>
                </div>
                <div class="postmaindescr">
                    <p>
                        <?php echo $response->results[0]->description;?>
                    </p>
                </div>
            </div>
            <!-- end .postmain -->



            <div class="postmain">
                <div class="postmaintitle">
                    <h3><?php echo config('siteconfig.scrhead_mpage')?></h3>
                </div>
                <div class="postscreens">
                    <?php foreach ( $response->results[0]->screenshotUrls as $screenshotUrl )
                    {
                        echo '<a class="fancybox" rel="group" href="'.$screenshotUrl.'"><img src="'.$screenshotUrl.'"></a>';
                    }
                    ?>
                </div>
            </div>
            <!-- end .postmain -->

            <?php
                $site_country = config('siteconfig.site_country');
                $link_id = $musicid;
                $jsonurl = "https://itunes.apple.com/$site_country/rss/customerreviews/page=1/id=$link_id/sortBy=mostRecent/json";
               $json = file_get_contents($jsonurl,0,null,null);
               $json_output = json_decode($json);

               $counter = 0;
               $max = 21;
            ?>




            <?php
            $reviewshead_mpage = config('siteconfig.reviewshead_mpage');
            $reviewsby_mpage = config('siteconfig.reviewsby_mpage');
            $site_country = config('siteconfig.site_country');
            $jsonurl = "https://itunes.apple.com/$site_country/rss/customerreviews/page=1/id=$musicid/sortBy=mostRecent/json";
            $json = file_get_contents($jsonurl,0,null,null);
            $json_output = json_decode($json);

            $counter = 0;
            $max = 21;
            if (!empty($json_output->feed->entry)) {
                echo '<div class="postmain">
<div class="postmaintitle">
<h3>'.$reviewshead_mpage.'</h3>
</div>

<div id="reviews">
<ul style="list-style:none;padding: 0px;">';
                foreach ( $json_output->feed->entry as $entry )
                {
                    if ($counter++ == 0) continue;
                    if ($counter < $max) {
                        echo "<li>";
                        echo "<h4 class=\"tit\">{$entry->title->label}</h4>\n";
                        echo '<div class="starbox"><span class="stars">'.$entry->{'im:rating'}->label.'</span></div>';
                        echo "<div class=\"auth\">{$reviewsby_mpage} {$entry->author->name->label}</div>\n";
                        echo "<div class=\"cont\">{$entry->content->label}</div>\n";
                        echo "</li>\n";
                    }
                    $counter++;
                }
                echo '</ul>
</div>
</div>
<!-- end .postmain -->';
            }
            else {}
            ?>


            <?php
            $disqus_shortname = config('siteconfig.disqus_shortname');
            $commentbox_mpage = config('siteconfig.commentbox_mpage');
            if(isset($disqus_shortname) and !empty($disqus_shortname)):
            ?>
            <div class="postmain">
                <div class="postmaintitle">
                    <h3><?php echo $commentbox_mpage;?></h3>
                </div>
                <div class="videocomments">
                    <div id="disqus_thread"></div>
                    <script type="text/javascript">
                        /* * * CONFIGURATION VARIABLES * * */
                        var disqus_shortname = '<?php echo $disqus_shortname;?>';

                        /* * * DON'T EDIT BELOW THIS LINE * * */
                        (function() {
                            var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
                            dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
                            (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
                        })();
                    </script>
                    <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>
                </div>
            </div>
        <?php endif; ?>

        <!-- end .postmain -->
        </div>
        <!-- .post-sidebar -->
        <div class="col-md-4" style="padding-right:0px;">
            <div class="post-sidebar">
                <div class="post-sidebar-box">

                    <h3><?php echo config('siteconfig.morebyartist_mpage')?> <?php echo e($artist_title); ?></h3>
                    <ul class="side-itemlist">
                        <?php
                        $site_url = config('siteconfig.site_url');
                        $data_al = file_get_contents('https://itunes.apple.com/lookup?id='.$response->results[0]->artistId.'&entity=software');
                        $response_al = json_decode($data_al);

                        if (isset($response_al->results) and $response_al->results == true){
                            foreach ($response_al->results as $result_al)
                            {
                                if ($result_al->wrapperType == 'software') {
                                    echo '<li class="side-item"><div class="side-thumb"><a href="'.$site_url.'/app/'.$result_al->trackId.'/'.$result_al->trackName.'"><img data-src="'.$result_al->artworkUrl100.'" src="'.$site_url.'/public/images/loading.svg" ></a></div>
	<div class="info"><h3><a href="'.$site_url.'/app/'.$result_al->trackId.'/'.$result_al->trackName.'">'.$result_al->trackName.'</a></h3>
		<h4>'.$result_al->artistName.'</h4>';
                                    if (isset($result_al->averageUserRating) and $result_al->averageUserRating == true){
                                        echo '<div class="starbox"><span class="stars">'.$result_al->averageUserRating.'</span></div>';
                                    }
                                    echo '</div>
	</li>';
                                }
                            }
                        }
                        ?>
                    </ul>

                </div>

            </div>
        </div>
        <!-- end .post-sidebar -->
    </div>
<?php endif; ?>



<script type="text/javascript" src="<?php echo asset('public/js/bigstar-rating.js'); ?>"></script>
<script type="text/javascript">
    jQuery(function() {
        jQuery('span.bigstars').bigstars();
    });
</script>
<script type="text/javascript" src="<?php echo asset('public/js/star-rating.js'); ?>"></script>
<script type="text/javascript">
    jQuery(function() {
        jQuery('span.stars').stars();
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $(".fancybox").fancybox();
    });
</script>
<script src="<?php echo config('siteconfig.site_url')?>/public/js/imglazyload.js"></script>
<script>
    //lazy loading
    $('.container img').imgLazyLoad({
        // jquery selector or JS object
        container: window,
        // jQuery animations: fadeIn, show, slideDown
        effect: 'fadeIn',
        // animation speed
        speed: 600,
        // animation delay
        delay: 400,
        // callback function
        callback: function(){}
    });
</script>
<script>
    $(document).ready(function(){

        // hide #back-top first
        $("#back-top").hide();

        // fade in #back-top
        $(function () {
            $(window).scroll(function () {
                if ($(this).scrollTop() > 200) {
                    $('#back-top').fadeIn();
                } else {
                    $('#back-top').fadeOut();
                }
            });

            // scroll body to 0px on click
            $('#back-top a').click(function () {
                $('body,html').animate({
                    scrollTop: 0
                }, 800);
                return false;
            });
        });

    });
</script>
<p id="back-top"><a href="#top"><i class="material-icons">keyboard_arrow_up</i></a></p>
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>