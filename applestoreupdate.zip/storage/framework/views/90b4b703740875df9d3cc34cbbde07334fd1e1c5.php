<!DOCTYPE html>
<!-- saved from url=(0047)http://mannatthemes.com/annex/crypto/login.html -->
<html class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>Annex - Responsive Bootstrap 4 Admin Dashboard</title>
    <meta content="Admin Dashboard" name="description">
    <meta content="Mannatthemes" name="author">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="http://mannatthemes.com/annex/crypto/assets/images/favicon.ico">
    <link rel="stylesheet" href="<?php echo asset('css/bootstrap.min.css'); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo asset('css/icons.css'); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo asset('css/styles.css'); ?>" type="text/css">
    <!-- pass php vars to javascript -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'appUrl' => url("/")
        ]); ?>
    </script>

</head>


<body style="overflow: visible;">

<div id="index">
    <Register></Register>
</div>

<script src="<?php echo asset('js/jquery.min.js'); ?>"></script>
<script src="<?php echo asset('js/popper.min.js'); ?>"></script>
<script src="<?php echo asset('js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo asset('js/modernizr.min.js'); ?>"></script>
<script src="<?php echo asset('js/waves.js'); ?>"></script>
<script src="<?php echo asset('js/jquery.slimscroll.js'); ?>"></script>
<script src="<?php echo asset('js/jquery.nicescroll.js'); ?>"></script>
<script src="<?php echo asset('js/jquery.scrollTo.min.js'); ?>"></script>
<script src="<?php echo asset('js/app.v1.js'); ?>"></script>
<script src="<?php echo asset('js/index.js'); ?>"></script>



</body></html>