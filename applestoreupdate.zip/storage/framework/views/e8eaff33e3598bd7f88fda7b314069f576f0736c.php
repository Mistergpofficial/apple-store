
<!-- Edit Class Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!--Modal Content -->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" role="form">
                    <?php echo e(csrf_field()); ?>


                    <p class="error text-center alert alert-danger hidden"></p>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="id">ID:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="class_id" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="class_name">CLASS NAME:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control"  id="class_name">

                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="numeric_name">NUMERIC NAME:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="numeric_name">
                        </div>
                    </div>
                    </form>
                <div class="deleteContent">
                    Are you sure you want to delete class&nbsp;<span class="clas_name"></span> ? <span class="hidden class_did"></span>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn actionBtn" data-dismiss="modal">
                        <span id="footer_action_button" class="glyphicon"></span>
                    </button>
                    <button type="button" class="btn btn-warning" data-dismiss="modal">
                        <span class="fa fa-close"></span>Close
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->