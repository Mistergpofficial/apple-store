<!DOCTYPE html>
<!-- saved from url=(0026)http://mychurchmember.com/ -->
<html lang="en" class="  js no-touch no-android chrome no-firefox no-iemobile no-ie no-ie10 no-ie11 no-ios no-ios7 ipad"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>Welcome | GIT-EDU </title>
    <meta name="description" content="">
    <meta name="detectify-verification" content="c1b33bd882c3936d9e0f4fca31e74b70">
    <meta name="google-site-verification" content="gOo-RWYqpVogdSR4wAFvmFlrVaYyB8986DEIah1unVs">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="./css/landing.css" type="text/css">
    <link rel="stylesheet" href="./css/app.v2.css" type="text/css">
    <link rel="stylesheet" href="./css/style.css" type="text/css">
    <link rel="stylesheet" href="./css/footer.css">
    <link rel="stylesheet" href="./css/font-awesome.min.css" type="text/css">


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


    <link rel="icon" type="image/png" href="./images/ad.jpg" width="40px">
    <style>
        .swiper-container {
            width: 100%;
            height: 400px;
        }
        .example-animation {
            color: #FFF;
            font-size: 60px;
        }
        @media    only screen
        and (min-device-width : 320px)
        and (max-device-width : 480px) {
            .title_caption{
                font-size: 15px;
            }
            .ullist{
                font-size: 10px;
            }
            .h3_title{
                margin-top: -10px;
                padding: 20px;
            }
        }

        /* Smartphones (landscape) ----------- */
        @media    only screen
        and (min-width : 321px) {
            .title_caption{
                font-size: 15px;
                margin-top: 10px;
            }
            .ullist{
                font-size: 10px;
            }
            .h3_title{
                margin-top: -10px;
                padding: 20px;
            }
        }

        /* Smartphones (portrait) ----------- */
        @media    only screen
        and (max-width : 320px) {
            .title_caption{
                font-size: 15px;
                margin-top: 10px;
            }
            .h3_title{
                margin-top: -10px;
                padding: 20px;
            }
            .ullist{
                font-size: 10px;
            }
        }

        /* iPads (portrait and landscape) ----------- */
        @media    only screen
        and (min-device-width : 768px)
        and (max-device-width : 1024px) {
            .title_caption{
                font-size: 28px;text-transform: uppercase;font-weight: bold;
            }
            .ullist{
                font-size: 16px;
            }
        }

        /* iPads (landscape) ----------- */
        @media    only screen
        and (min-device-width : 768px)
        and (max-device-width : 1024px)
        and (orientation : landscape) {
            .title_caption{
                font-size: 28px;text-transform: uppercase;font-weight: bold;
            }
            .ullist{
                font-size: 16px;
            }
        }

        /* iPads (portrait) ----------- */
        @media    only screen
        and (min-device-width : 768px)
        and (max-device-width : 1024px)
        and (orientation : portrait) {
            .title_caption{
                font-size: 28px;text-transform: uppercase;font-weight: bold;
            }
            .ullist{
                font-size: 16px;
            }
        }

        /* Desktops and laptops ----------- */
        @media    only screen
        and (min-width : 1224px) {
            .title_caption{
                font-size: 28px;text-transform: uppercase;font-weight: bold;
            }
            .ullist{
                font-size: 16px;
            }
        }

        /* Large screens ----------- */
        @media    only screen
        and (min-width : 1824px) {
            .title_caption{
                font-size: 28px;text-transform: uppercase;font-weight: bold;
            }
        }

        /* iPhone 5 (portrait & landscape)----------- */
        @media    only screen
        and (min-device-width : 320px)
        and (max-device-width : 568px) {
            .title_caption{
                font-size: 15px;
                margin-top: 10px;
            }
            .ullist{
                font-size: 10px;
            }
            .h3_title{
                margin-top: -10px;
                padding: 20px;
            }
        }

        /* iPhone 5 (landscape)----------- */
        @media    only screen
        and (min-device-width : 320px)
        and (max-device-width : 568px)
        and (orientation : landscape) {
            .title_caption{
                font-size: 15px;
                margin-top: 10px;
            }
            .ullist{
                font-size: 10px;
            }
            .h3_title{
                margin-top: -10px;
                padding: 20px;
            }
        }

        /* iPhone 5 (portrait)----------- */
        @media    only screen
        and (min-device-width : 320px)
        and (max-device-width : 568px)
        and (orientation : portrait) {
            .title_caption{
                font-size: 15px;
                margin-top: 10px;
            }
            .ullist{
                font-size: 10px;
            }
            .h3_title{
                margin-top: -10px;
                padding: 20px;
            }
        }

        .form-co{
            display: block;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
            -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
        }

    </style>
    <!--[if lt IE 9]>
    <script src="js/ie/html5shiv.js"></script>
    <script src="js/ie/respond.min.js"></script>
    <script src="js/ie/excanvas.js"></script> <![endif]-->
    <script async="" src="./js/hotjar-376426.js.download"></script><script async="" src=""></script><style type="text/css">iframe#_hjRemoteVarsFrame {display: none !important; width: 1px !important; height: 1px !important; opacity: 0 !important; pointer-events: none !important;}</style></head>
<body class="">
<!-- header -->
<header id="header" class="navbar navbar-fixed-top bg-white box-shadow b-b b-light affix" data-spy="affix" data-offset-top="1">
    <div class="container">
        <div class="navbar-header"><a href="<?php echo e(url('/')); ?>" class="navbar-brand"><img src="./images/ad.jpg" width="40px" class="m-r-sm"><span class="text-muted">GIT-EDU</span></a>
            <button class="btn btn-link visible-xs" type="button" data-toggle="collapse" data-target=".navbar-collapse">
                <i class="fa fa-bars"></i></button>
            <!-- <span style="color: #5cb85c" class="hidden-xs hidden-sm">Delivering the most usable hrms </span> -->

        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="m-t-sm">
                        <a href="" class="btn btn-sm btn-link m-l"><strong>Home</strong></a>
                        <a href="" class="btn btn-sm btn-link m-l"><strong>About</strong></a>
                        <a href="" class="btn btn-sm btn-link m-l"><strong>Blog</strong></a>
                        <a href="<?php echo e(url('signin')); ?>" class="btn btn-link btn-sm"><strong>Sign in</strong></a>
                        <a href="" class="btn btn-sm btn-success m-l"><strong>Sign up<!--<span class="label label-warning">Free 1 month trial</span>--></strong></a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</header>
<!-- / header -->
<?php echo $__env->yieldContent('content'); ?>
<!-- Footer-->
<footer class=" wow fadeInUp animated" data-wow-duration="500ms" data-wow-delay="300ms" style="visibility: visible; animation-duration: 500ms; animation-delay: 300ms; animation-name: fadeInUp;">

    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">

                <p>Copyright © 2017 GIT-EDU</p>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap --> <!-- App -->
<script src="./js/app.v2.js"></script>

</body></html>