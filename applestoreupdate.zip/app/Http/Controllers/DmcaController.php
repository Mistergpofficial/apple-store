<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DmcaController extends Controller
{
    public function dmca(){
        return view('dmca_main');
    }
}
